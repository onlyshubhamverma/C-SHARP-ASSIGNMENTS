﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculator
{
    using System;

    namespace Structure
    {


        enum BookType : byte
        {
            Magazine = 10,
            Novel = 1,
            ReferenceBook = 100,
            Miscellaneous = 9
        }

        struct BOOK
        {
            public int BookID;
            public string title;
            public short Price;
            public BookType heading;


            public BOOK(int i, string n, short p, BookType h)
            {
                BookID = i;
                title = n;
                Price = p;
                heading = h;

            }
        }

        class MainClass
        {
            public static void Main(string[] args)
            {
                BOOK wings;
                wings.BookID = 30;
                wings.title = "chetan";
                wings.Price = 250;
                wings.heading = BookType.Novel;

                BOOK chhan bagat = new BOOK(40, "chetan bagat", 500, BookType.Magazine);

                Console.WriteLine("BookID is {0} ", chetan bagat.BookID);
                Console.WriteLine("Title is {0}", chetan bagat.title);
                Console.WriteLine("Price is {0}", chetan bagat.Price);
                Console.WriteLine("Type of the book is {0}", chetan bagat.heading);

                Console.WriteLine("\n");

                Console.WriteLine("BookID is {0}", wings.BookID);
                Console.WriteLine("Title is {0}", wings.title);
                Console.WriteLine("Price is {0}", wings.Price);
                Console.WriteLine("Typeof the book is {0}", wings.heading);


            }
        }
    }
}
